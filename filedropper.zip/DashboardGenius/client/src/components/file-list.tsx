import { useState } from "react";
import { Download, FileText, Image, Film, Archive, File, Clock, AlertCircle, ArrowLeft, Package } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Progress } from "./ui/progress";
import { format } from "date-fns";
import type { TransferWithFiles } from "@shared/schema";

interface FileListProps {
  transfer: TransferWithFiles;
  onBack: () => void;
}

export function FileList({ transfer, onBack }: FileListProps) {
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return <Image className="w-5 h-5" />;
    if (mimeType.startsWith('video/')) return <Film className="w-5 h-5" />;
    if (mimeType.includes('zip') || mimeType.includes('archive')) return <Archive className="w-5 h-5" />;
    if (mimeType.includes('pdf') || mimeType.includes('document')) return <FileText className="w-5 h-5" />;
    return <File className="w-5 h-5" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  const handleDownload = async (fileId: string, fileName: string) => {
    setDownloadingFile(fileId);
    setDownloadProgress(0);

    try {
      const response = await fetch(`/api/transfers/${transfer.code}/download/${fileId}`);
      
      if (!response.ok) throw new Error('Download failed');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      setDownloadProgress(100);
      setTimeout(() => {
        setDownloadProgress(null);
        setDownloadingFile(null);
      }, 1000);
    } catch (error) {
      console.error('Download failed:', error);
      setDownloadProgress(null);
      setDownloadingFile(null);
    }
  };

  const handleDownloadAll = async () => {
    setDownloadProgress(0);

    try {
      const response = await fetch(`/api/transfers/${transfer.code}/download-all`);
      
      if (!response.ok) throw new Error('Download failed');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `transfer-${transfer.code}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      setDownloadProgress(100);
      setTimeout(() => setDownloadProgress(null), 1000);
    } catch (error) {
      console.error('Download failed:', error);
      setDownloadProgress(null);
    }
  };

  const expiryDate = new Date(transfer.expiresAt);
  const now = new Date();
  const isExpiringSoon = expiryDate.getTime() - now.getTime() < 3600000; // Less than 1 hour

  const remainingDownloads = transfer.maxDownloads 
    ? transfer.maxDownloads - transfer.downloadCount 
    : null;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          data-testid="button-back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-files-heading">
            Transfer Files
          </h1>
          <p className="text-sm text-muted-foreground">
            Code: <span className="font-mono font-medium">{transfer.code}</span>
          </p>
        </div>
      </div>

      {isExpiringSoon && (
        <Card className="p-4 bg-chart-3/10 border-chart-3/20">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-chart-3 mt-0.5" />
            <div>
              <p className="font-medium text-chart-3">Expiring Soon</p>
              <p className="text-sm text-chart-3/90">
                This transfer expires on {format(expiryDate, "MMM d, yyyy 'at' h:mm a")}
              </p>
            </div>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium text-muted-foreground">Expires</p>
              <p className="font-medium" data-testid="text-expiry-info">
                {format(expiryDate, "MMM d, h:mm a")}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium text-muted-foreground">Files</p>
              <p className="font-medium" data-testid="text-files-count">
                {transfer.files.length} file{transfer.files.length !== 1 ? 's' : ''}
              </p>
            </div>
          </div>
        </Card>

        {remainingDownloads !== null && (
          <Card className="p-6">
            <div className="flex items-start gap-3">
              <Download className="w-5 h-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Downloads Left</p>
                <p className="font-medium" data-testid="text-downloads-remaining">
                  {remainingDownloads} remaining
                </p>
              </div>
            </div>
          </Card>
        )}
      </div>

      <Card className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Files</h2>
          <Button onClick={handleDownloadAll} data-testid="button-download-all">
            <Package className="w-4 h-4 mr-2" />
            Download All as ZIP
          </Button>
        </div>

        {downloadProgress !== null && (
          <div className="space-y-2">
            <Progress value={downloadProgress} className="h-2" data-testid="progress-download" />
            <p className="text-sm text-center text-muted-foreground">
              Downloading... {downloadProgress}%
            </p>
          </div>
        )}

        <div className="space-y-2">
          {transfer.files.map((file) => (
            <div
              key={file.id}
              className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover-elevate transition-all"
              data-testid={`file-row-${file.id}`}
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="text-muted-foreground">
                  {getFileIcon(file.mimeType)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate" data-testid={`text-filename-${file.id}`}>
                    {file.originalName}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {formatFileSize(file.size)}
                  </p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleDownload(file.id, file.originalName)}
                disabled={downloadingFile === file.id}
                data-testid={`button-download-${file.id}`}
              >
                <Download className="w-4 h-4 mr-2" />
                {downloadingFile === file.id ? 'Downloading...' : 'Download'}
              </Button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
