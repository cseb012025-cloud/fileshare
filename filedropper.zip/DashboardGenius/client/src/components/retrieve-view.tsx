import { useState, useRef, KeyboardEvent } from "react";
import { Download, Lock, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useQuery } from "@tanstack/react-query";
import type { TransferWithFiles } from "@shared/schema";
import { FileList } from "./file-list";

export function RetrieveView() {
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [password, setPassword] = useState('');
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [error, setError] = useState('');
  const [transferData, setTransferData] = useState<TransferWithFiles | null>(null);
  
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleDigitChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    
    const newCode = [...code];
    newCode[index] = value.slice(-1);
    setCode(newCode);
    setError('');

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    const newCode = [...code];
    
    for (let i = 0; i < pastedData.length; i++) {
      newCode[i] = pastedData[i];
    }
    
    setCode(newCode);
    
    if (pastedData.length === 6) {
      inputRefs.current[5]?.focus();
    } else if (pastedData.length > 0) {
      inputRefs.current[Math.min(pastedData.length, 5)]?.focus();
    }
  };

  const handleAccessFiles = async () => {
    const fullCode = code.join('');
    
    if (fullCode.length !== 6) {
      setError('Please enter a complete 6-digit code');
      return;
    }

    try {
      const response = await fetch(`/api/transfers/${fullCode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: password || undefined }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 401) {
          setShowPasswordInput(true);
          setError(data.error || 'Password required');
        } else {
          setError(data.error || 'Failed to access transfer');
        }
        return;
      }

      setTransferData(data);
      setError('');
    } catch (err) {
      setError('Failed to access transfer. Please try again.');
    }
  };

  if (transferData) {
    return <FileList transfer={transferData} onBack={() => setTransferData(null)} />;
  }

  return (
    <div className="w-full max-w-md mx-auto space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl md:text-5xl font-bold leading-tight" data-testid="text-retrieve-heading">
          Retrieve Your Files
        </h1>
        <p className="text-base md:text-lg text-muted-foreground" data-testid="text-retrieve-subheading">
          Enter the 6-digit code to access your files
        </p>
      </div>

      <Card className="p-8 space-y-6">
        <div className="space-y-4">
          <Label htmlFor="code-0" className="text-sm font-medium">
            Transfer Code
          </Label>
          <div className="flex gap-2 justify-center" onPaste={handlePaste}>
            {code.map((digit, index) => (
              <Input
                key={index}
                id={`code-${index}`}
                ref={(el) => (inputRefs.current[index] = el)}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleDigitChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-14 text-center text-2xl font-mono font-medium"
                data-testid={`input-code-${index}`}
              />
            ))}
          </div>
        </div>

        {showPasswordInput && (
          <div className="space-y-2">
            <Label htmlFor="password" className="text-sm font-medium flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Password Required
            </Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAccessFiles()}
              data-testid="input-retrieve-password"
            />
          </div>
        )}

        {error && (
          <div className="flex items-start gap-2 p-4 bg-destructive/10 border border-destructive/20 rounded-lg" data-testid="text-error">
            <AlertCircle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        <Button
          size="lg"
          className="w-full"
          onClick={handleAccessFiles}
          data-testid="button-access-files"
        >
          <Download className="w-4 h-4 mr-2" />
          Access Files
        </Button>
      </Card>

      <div className="text-center">
        <p className="text-sm text-muted-foreground">
          Files are automatically deleted after expiration
        </p>
      </div>
    </div>
  );
}
