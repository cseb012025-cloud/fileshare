import { useState } from "react";
import { CheckCircle, Copy, Clock, FileText, HardDrive, Download, ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface SuccessViewProps {
  code: string;
  qrCode: string;
  expiresAt: string;
  fileCount: number;
  totalSize: string;
  maxDownloads?: number;
  onCreateAnother: () => void;
}

export function SuccessView({
  code,
  qrCode,
  expiresAt,
  fileCount,
  totalSize,
  maxDownloads,
  onCreateAnother,
}: SuccessViewProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const shareLink = `${window.location.origin}?code=${code}`;

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    toast({
      title: "Code copied!",
      description: "Transfer code copied to clipboard",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(shareLink);
    setLinkCopied(true);
    toast({
      title: "Link copied!",
      description: "Share link copied to clipboard",
    });
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const expiryDate = new Date(expiresAt);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-full bg-chart-2/20 flex items-center justify-center">
            <CheckCircle className="w-8 h-8 text-chart-2" />
          </div>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold" data-testid="text-success-heading">
          Transfer Created Successfully!
        </h1>
        <p className="text-base text-muted-foreground">
          Share this code with the recipient to download the files
        </p>
      </div>

      <Card className="p-8 space-y-6">
        <div className="space-y-3">
          <Label className="text-sm font-medium text-muted-foreground">Transfer Code</Label>
          <div className="relative">
            <div 
              className="flex items-center justify-center p-6 bg-muted rounded-lg border-2 border-border"
              data-testid="text-transfer-code"
            >
              <span className="font-mono text-4xl md:text-5xl font-medium tracking-[0.3em]">
                {code}
              </span>
            </div>
            <Button
              size="icon"
              variant="outline"
              className="absolute top-2 right-2"
              onClick={copyCode}
              data-testid="button-copy-code"
            >
              {copied ? (
                <CheckCircle className="w-4 h-4 text-chart-2" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        <div className="flex justify-center py-4">
          <div className="p-4 bg-white rounded-lg" data-testid="image-qr-code">
            <img src={qrCode} alt="QR Code" className="w-64 h-64" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
            <Clock className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium">Expires</p>
              <p className="text-sm text-muted-foreground" data-testid="text-expiry-date">
                {format(expiryDate, "MMM d, yyyy 'at' h:mm a")}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
            <FileText className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium">Files</p>
              <p className="text-sm text-muted-foreground" data-testid="text-file-count">
                {fileCount} file{fileCount !== 1 ? 's' : ''}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
            <HardDrive className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium">Total Size</p>
              <p className="text-sm text-muted-foreground" data-testid="text-total-size">
                {totalSize}
              </p>
            </div>
          </div>

          {maxDownloads && (
            <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
              <Download className="w-5 h-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm font-medium">Download Limit</p>
                <p className="text-sm text-muted-foreground" data-testid="text-max-downloads">
                  {maxDownloads} downloads
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <Label className="text-sm font-medium text-muted-foreground">Share Link</Label>
          <div className="flex gap-2">
            <Input
              value={shareLink}
              readOnly
              className="flex-1 font-mono text-sm"
              data-testid="input-share-link"
            />
            <Button
              variant="outline"
              onClick={copyLink}
              data-testid="button-copy-link"
            >
              {linkCopied ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2 text-chart-2" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>

      <Button
        variant="outline"
        size="lg"
        className="w-full"
        onClick={onCreateAnother}
        data-testid="button-create-another"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Create Another Transfer
      </Button>
    </div>
  );
}
