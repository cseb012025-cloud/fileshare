import { useState, useRef, DragEvent } from "react";
import { CloudUpload, Upload, FolderOpen, Lock, Clock, Download, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Switch } from "./ui/switch";
import { Progress } from "./ui/progress";

interface UploadViewProps {
  onUploadSuccess: (data: {
    code: string;
    qrCode: string;
    expiresAt: string;
    transferId: string;
    fileCount: number;
    totalSize: string;
    maxDownloads?: number;
  }) => void;
}

export function UploadView({ onUploadSuccess }: UploadViewProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState('');
  
  const [expirationValue, setExpirationValue] = useState("24");
  const [expirationUnit, setExpirationUnit] = useState<"minutes" | "hours" | "days">("hours");
  const [usePassword, setUsePassword] = useState(false);
  const [password, setPassword] = useState("");
  const [useMaxDownloads, setUseMaxDownloads] = useState(false);
  const [maxDownloads, setMaxDownloads] = useState("10");

  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    setFiles(prev => [...prev, ...droppedFiles]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      setFiles(prev => [...prev, ...selectedFiles]);
    }
  };

  const handleUpload = async () => {
    if (files.length === 0) return;

    setIsUploading(true);
    setUploadProgress(0);
    setUploadError('');

    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    formData.append('expirationValue', expirationValue);
    formData.append('expirationUnit', expirationUnit);
    if (usePassword && password) {
      formData.append('password', password);
    }
    if (useMaxDownloads && maxDownloads) {
      formData.append('maxDownloads', maxDownloads);
    }

    try {
      const xhr = new XMLHttpRequest();
      
      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          const percentComplete = (e.loaded / e.total) * 100;
          setUploadProgress(Math.round(percentComplete));
        }
      });

      xhr.addEventListener('load', () => {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText);
          onUploadSuccess({
            code: response.code,
            qrCode: response.qrCode,
            expiresAt: response.expiresAt,
            transferId: response.id,
            fileCount: response.fileCount,
            totalSize: formatFileSize(response.totalSize),
            maxDownloads: useMaxDownloads && maxDownloads ? parseInt(maxDownloads) : undefined,
          });
        } else {
          const response = JSON.parse(xhr.responseText);
          setUploadError(response.error || 'Upload failed');
          setIsUploading(false);
        }
      });

      xhr.addEventListener('error', () => {
        setUploadError('Upload failed. Please try again.');
        setIsUploading(false);
      });

      xhr.open('POST', '/api/transfers/upload');
      xhr.send(formData);
    } catch (error) {
      console.error('Upload failed:', error);
      setIsUploading(false);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  const totalSize = files.reduce((sum, file) => sum + file.size, 0);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl md:text-5xl font-bold leading-tight" data-testid="text-upload-heading">
          Share Files Securely
        </h1>
        <p className="text-base md:text-lg text-muted-foreground" data-testid="text-upload-subheading">
          Upload files or folders. Generate a code. Share instantly.
        </p>
      </div>

      <Card className="p-8 space-y-6">
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative min-h-[320px] border-2 border-dashed rounded-2xl transition-all duration-200 ${
            isDragging 
              ? 'border-primary bg-primary/5' 
              : 'border-border hover-elevate'
          }`}
          data-testid="dropzone-upload"
        >
          {files.length === 0 ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
              <CloudUpload className="w-16 h-16 text-primary mb-4" strokeWidth={2} />
              <h3 className="text-xl font-semibold mb-2">Drop files or folders here</h3>
              <p className="text-sm text-muted-foreground mb-6">
                or click the buttons below to browse
              </p>
            </div>
          ) : (
            <div className="p-6 space-y-3 max-h-[300px] overflow-y-auto">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-lg hover-elevate"
                  data-testid={`file-item-${index}`}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{file.name}</p>
                    <p className="text-sm text-muted-foreground">{formatFileSize(file.size)}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(index)}
                    data-testid={`button-remove-file-${index}`}
                  >
                    Remove
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex gap-4">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
            data-testid="input-file"
          />
          <input
            ref={folderInputRef}
            type="file"
            onChange={handleFileSelect}
            className="hidden"
            data-testid="input-folder"
            {...({ webkitdirectory: '', directory: '' } as any)}
          />
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => fileInputRef.current?.click()}
            data-testid="button-select-files"
          >
            <Upload className="w-4 h-4 mr-2" />
            Select Files
          </Button>
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => folderInputRef.current?.click()}
            data-testid="button-select-folder"
          >
            <FolderOpen className="w-4 h-4 mr-2" />
            Select Folder
          </Button>
        </div>

        {files.length > 0 && (
          <div className="pt-4 border-t">
            <p className="text-sm font-medium text-muted-foreground">
              {files.length} file{files.length !== 1 ? 's' : ''} · {formatFileSize(totalSize)}
            </p>
          </div>
        )}
      </Card>

      <Card className="p-8 space-y-6">
        <h3 className="text-lg font-semibold">Transfer Settings</h3>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="expiration" className="text-sm font-medium flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Expiration Time
            </Label>
            <div className="flex gap-3">
              <Input
                id="expiration"
                type="number"
                min="1"
                value={expirationValue}
                onChange={(e) => setExpirationValue(e.target.value)}
                className="flex-1"
                data-testid="input-expiration-value"
              />
              <Select value={expirationUnit} onValueChange={(value: any) => setExpirationUnit(value)}>
                <SelectTrigger className="w-32" data-testid="select-expiration-unit">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="minutes">Minutes</SelectItem>
                  <SelectItem value="hours">Hours</SelectItem>
                  <SelectItem value="days">Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="password-toggle" className="text-sm font-medium flex items-center gap-2">
                <Lock className="w-4 h-4" />
                Password Protection
              </Label>
              <Switch
                id="password-toggle"
                checked={usePassword}
                onCheckedChange={setUsePassword}
                data-testid="switch-password"
              />
            </div>
            {usePassword && (
              <Input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                data-testid="input-password"
              />
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="max-downloads-toggle" className="text-sm font-medium flex items-center gap-2">
                <Download className="w-4 h-4" />
                Limit Downloads
              </Label>
              <Switch
                id="max-downloads-toggle"
                checked={useMaxDownloads}
                onCheckedChange={setUseMaxDownloads}
                data-testid="switch-max-downloads"
              />
            </div>
            {useMaxDownloads && (
              <Input
                type="number"
                min="1"
                placeholder="Maximum downloads"
                value={maxDownloads}
                onChange={(e) => setMaxDownloads(e.target.value)}
                data-testid="input-max-downloads"
              />
            )}
          </div>
        </div>
      </Card>

      {isUploading && (
        <div className="space-y-2">
          <Progress value={uploadProgress} className="h-2" data-testid="progress-upload" />
          <p className="text-sm text-center text-muted-foreground">
            Uploading... {uploadProgress}%
          </p>
        </div>
      )}

      {uploadError && (
        <div className="flex items-start gap-2 p-4 bg-destructive/10 border border-destructive/20 rounded-lg" data-testid="text-upload-error">
          <AlertCircle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
          <p className="text-sm text-destructive">{uploadError}</p>
        </div>
      )}

      <Button
        size="lg"
        className="w-full"
        onClick={handleUpload}
        disabled={files.length === 0 || isUploading}
        data-testid="button-generate-code"
      >
        {isUploading ? 'Uploading...' : 'Generate Transfer Code'}
      </Button>
    </div>
  );
}
