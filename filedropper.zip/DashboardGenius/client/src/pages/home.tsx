import { useState, useEffect } from "react";
import { Upload as UploadIcon, Download } from "lucide-react";
import { UploadView } from "@/components/upload-view";
import { SuccessView } from "@/components/success-view";
import { RetrieveView } from "@/components/retrieve-view";
import { ThemeToggle } from "@/components/theme-toggle";

type View = 'upload' | 'retrieve' | 'success';

interface SuccessData {
  code: string;
  qrCode: string;
  expiresAt: string;
  transferId: string;
  fileCount: number;
  totalSize: string;
  maxDownloads?: number;
}

export default function Home() {
  const [activeView, setActiveView] = useState<View>('upload');
  const [successData, setSuccessData] = useState<SuccessData | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    if (code) {
      setActiveView('retrieve');
    }
  }, []);

  const handleUploadSuccess = (data: SuccessData) => {
    setSuccessData(data);
    setActiveView('success');
  };

  const handleCreateAnother = () => {
    setSuccessData(null);
    setActiveView('upload');
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <UploadIcon className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold" data-testid="text-app-name">SecureShare</span>
          </div>

          <div className="flex items-center gap-2">
            {activeView !== 'success' && (
              <div className="flex items-center gap-1 p-1 bg-muted rounded-lg">
                <button
                  onClick={() => setActiveView('upload')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    activeView === 'upload'
                      ? 'bg-background text-foreground shadow-sm'
                      : 'text-muted-foreground hover-elevate'
                  }`}
                  data-testid="button-view-upload"
                >
                  <UploadIcon className="w-4 h-4" />
                  <span className="hidden sm:inline">Upload</span>
                </button>
                <button
                  onClick={() => setActiveView('retrieve')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    activeView === 'retrieve'
                      ? 'bg-background text-foreground shadow-sm'
                      : 'text-muted-foreground hover-elevate'
                  }`}
                  data-testid="button-view-retrieve"
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Retrieve</span>
                </button>
              </div>
            )}
            
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="container py-8 px-4 md:py-12 md:px-8">
        {activeView === 'upload' && (
          <UploadView onUploadSuccess={handleUploadSuccess} />
        )}
        {activeView === 'retrieve' && <RetrieveView />}
        {activeView === 'success' && successData && (
          <SuccessView
            code={successData.code}
            qrCode={successData.qrCode}
            expiresAt={successData.expiresAt}
            fileCount={successData.fileCount}
            totalSize={successData.totalSize}
            maxDownloads={successData.maxDownloads}
            onCreateAnother={handleCreateAnother}
          />
        )}
      </main>

      <footer className="border-t py-6 md:py-8">
        <div className="container text-center text-sm text-muted-foreground px-4">
          <p>Files are automatically deleted after expiration. No data is stored permanently.</p>
        </div>
      </footer>
    </div>
  );
}
