import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import archiver from "archiver";
import QRCode from "qrcode";
import bcrypt from "bcrypt";
import { randomInt } from "crypto";
import path from "path";
import fs from "fs/promises";
import { existsSync } from "fs";

const UPLOADS_DIR = path.join(process.cwd(), "uploads");
const MAX_FILE_SIZE = parseInt(process.env.MAX_UPLOAD_SIZE_MB || "100") * 1024 * 1024;

async function ensureUploadsDir() {
  if (!existsSync(UPLOADS_DIR)) {
    await fs.mkdir(UPLOADS_DIR, { recursive: true });
  }
}

const upload = multer({
  storage: multer.diskStorage({
    destination: async (req, file, cb) => {
      await ensureUploadsDir();
      cb(null, UPLOADS_DIR);
    },
    filename: (req, file, cb) => {
      const uniqueName = `${Date.now()}-${randomInt(10000)}-${file.originalname}`;
      cb(null, uniqueName);
    },
  }),
  limits: {
    fileSize: MAX_FILE_SIZE,
  },
});

function generateUniqueCode(): string {
  return String(randomInt(100000, 999999));
}

async function generateUniqueTransferCode(): Promise<string> {
  let code = generateUniqueCode();
  let attempts = 0;
  
  while (attempts < 10) {
    const existing = await storage.getTransferByCode(code);
    if (!existing) return code;
    code = generateUniqueCode();
    attempts++;
  }
  
  throw new Error("Could not generate unique code");
}

function calculateExpiration(value: number, unit: 'minutes' | 'hours' | 'days'): Date {
  const now = new Date();
  const multipliers = { minutes: 1, hours: 60, days: 1440 };
  const minutes = value * multipliers[unit];
  return new Date(now.getTime() + minutes * 60 * 1000);
}

function sanitizeFilename(filename: string): string {
  return filename.replace(/[^a-zA-Z0-9._-]/g, '_');
}

async function cleanupExpiredTransfers() {
  try {
    const expiredTransfers = await storage.getExpiredTransfers();
    
    for (const transfer of expiredTransfers) {
      const files = await storage.getTransferFiles(transfer.id);
      
      for (const file of files) {
        const filePath = path.join(UPLOADS_DIR, file.storedName);
        try {
          if (existsSync(filePath)) {
            await fs.unlink(filePath);
          }
        } catch (error) {
          console.error(`Failed to delete file: ${filePath}`, error);
        }
      }
      
      await storage.deleteTransfer(transfer.id);
    }
    
    if (expiredTransfers.length > 0) {
      console.log(`Cleaned up ${expiredTransfers.length} expired transfer(s)`);
    }
  } catch (error) {
    console.error('Cleanup job failed:', error);
  }
}

setInterval(cleanupExpiredTransfers, 5 * 60 * 1000);

export async function registerRoutes(app: Express): Promise<Server> {
  await ensureUploadsDir();
  
  cleanupExpiredTransfers();

  app.post('/api/transfers/upload', upload.array('files', 50), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      
      if (!files || files.length === 0) {
        return res.status(400).json({ error: 'No files uploaded' });
      }

      const { expirationValue, expirationUnit, password, maxDownloads } = req.body;

      if (!expirationValue || !expirationUnit) {
        return res.status(400).json({ error: 'Expiration time required' });
      }

      const code = await generateUniqueTransferCode();
      const expiresAt = calculateExpiration(
        parseInt(expirationValue),
        expirationUnit as 'minutes' | 'hours' | 'days'
      );

      let passwordHash: string | null = null;
      if (password) {
        passwordHash = await bcrypt.hash(password, 10);
      }

      const totalSize = files.reduce((sum, file) => sum + file.size, 0);

      const transfer = await storage.createTransfer({
        code,
        passwordHash,
        expiresAt,
        maxDownloads: maxDownloads ? parseInt(maxDownloads) : null,
        totalSize,
        fileCount: files.length,
      });

      for (const file of files) {
        await storage.createTransferFile({
          transferId: transfer.id,
          originalName: file.originalname,
          storedName: file.filename,
          size: file.size,
          mimeType: file.mimetype,
        });
      }

      const shareUrl = `${req.protocol}://${req.get('host')}?code=${code}`;
      const qrCode = await QRCode.toDataURL(shareUrl);

      res.json({
        id: transfer.id,
        code,
        qrCode,
        expiresAt: transfer.expiresAt.toISOString(),
        fileCount: files.length,
        totalSize,
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ error: 'Upload failed' });
    }
  });

  app.post('/api/transfers/:code', async (req, res) => {
    try {
      const { code } = req.params;
      const { password } = req.body;

      const transfer = await storage.getTransferWithFiles(code);

      if (!transfer) {
        return res.status(404).json({ error: 'Transfer not found' });
      }

      if (transfer.expiresAt < new Date()) {
        await storage.deleteTransfer(transfer.id);
        return res.status(410).json({ error: 'Transfer expired' });
      }

      if (transfer.maxDownloads && transfer.downloadCount >= transfer.maxDownloads) {
        return res.status(403).json({ error: 'Download limit reached' });
      }

      if (transfer.passwordHash) {
        if (!password) {
          return res.status(401).json({ error: 'Password required' });
        }

        const isValid = await bcrypt.compare(password, transfer.passwordHash);
        if (!isValid) {
          return res.status(401).json({ error: 'Incorrect password' });
        }
      }

      res.json(transfer);
    } catch (error) {
      console.error('Retrieve error:', error);
      res.status(500).json({ error: 'Failed to retrieve transfer' });
    }
  });

  app.get('/api/transfers/:code/download/:fileId', async (req, res) => {
    try {
      const { code, fileId } = req.params;

      const transfer = await storage.getTransferByCode(code);
      if (!transfer) {
        return res.status(404).json({ error: 'Transfer not found' });
      }

      if (transfer.expiresAt < new Date()) {
        return res.status(410).json({ error: 'Transfer expired' });
      }

      const file = await storage.getTransferFile(fileId);
      if (!file || file.transferId !== transfer.id) {
        return res.status(404).json({ error: 'File not found' });
      }

      const filePath = path.join(UPLOADS_DIR, file.storedName);
      
      if (!existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found on server' });
      }

      await storage.incrementDownloadCount(transfer.id);

      res.download(filePath, sanitizeFilename(file.originalName));
    } catch (error) {
      console.error('Download error:', error);
      res.status(500).json({ error: 'Download failed' });
    }
  });

  app.get('/api/transfers/:code/download-all', async (req, res) => {
    try {
      const { code } = req.params;

      const transfer = await storage.getTransferWithFiles(code);
      if (!transfer) {
        return res.status(404).json({ error: 'Transfer not found' });
      }

      if (transfer.expiresAt < new Date()) {
        return res.status(410).json({ error: 'Transfer expired' });
      }

      await storage.incrementDownloadCount(transfer.id);

      const archive = archiver('zip', { zlib: { level: 9 } });

      res.attachment(`transfer-${code}.zip`);
      archive.pipe(res);

      for (const file of transfer.files) {
        const filePath = path.join(UPLOADS_DIR, file.storedName);
        if (existsSync(filePath)) {
          archive.file(filePath, { name: sanitizeFilename(file.originalName) });
        }
      }

      await archive.finalize();
    } catch (error) {
      console.error('Download all error:', error);
      res.status(500).json({ error: 'Download failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
