import { type Transfer, type InsertTransfer, type TransferFile, type InsertTransferFile, type TransferWithFiles } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createTransfer(transfer: InsertTransfer): Promise<Transfer>;
  getTransferByCode(code: string): Promise<Transfer | undefined>;
  getTransferWithFiles(code: string): Promise<TransferWithFiles | undefined>;
  incrementDownloadCount(transferId: string): Promise<void>;
  deleteTransfer(transferId: string): Promise<void>;
  getExpiredTransfers(): Promise<Transfer[]>;
  
  createTransferFile(file: InsertTransferFile): Promise<TransferFile>;
  getTransferFiles(transferId: string): Promise<TransferFile[]>;
  getTransferFile(fileId: string): Promise<TransferFile | undefined>;
}

export class MemStorage implements IStorage {
  private transfers: Map<string, Transfer>;
  private transferFiles: Map<string, TransferFile>;

  constructor() {
    this.transfers = new Map();
    this.transferFiles = new Map();
  }

  async createTransfer(insertTransfer: InsertTransfer): Promise<Transfer> {
    const id = randomUUID();
    const transfer: Transfer = {
      id,
      ...insertTransfer,
      downloadCount: 0,
      createdAt: new Date(),
    };
    this.transfers.set(id, transfer);
    return transfer;
  }

  async getTransferByCode(code: string): Promise<Transfer | undefined> {
    return Array.from(this.transfers.values()).find(t => t.code === code);
  }

  async getTransferWithFiles(code: string): Promise<TransferWithFiles | undefined> {
    const transfer = await this.getTransferByCode(code);
    if (!transfer) return undefined;

    const files = await this.getTransferFiles(transfer.id);
    return { ...transfer, files };
  }

  async incrementDownloadCount(transferId: string): Promise<void> {
    const transfer = this.transfers.get(transferId);
    if (transfer) {
      transfer.downloadCount += 1;
      this.transfers.set(transferId, transfer);
    }
  }

  async deleteTransfer(transferId: string): Promise<void> {
    this.transfers.delete(transferId);
    const filesToDelete = Array.from(this.transferFiles.values())
      .filter(f => f.transferId === transferId);
    filesToDelete.forEach(f => this.transferFiles.delete(f.id));
  }

  async getExpiredTransfers(): Promise<Transfer[]> {
    const now = new Date();
    return Array.from(this.transfers.values()).filter(t => t.expiresAt < now);
  }

  async createTransferFile(insertFile: InsertTransferFile): Promise<TransferFile> {
    const id = randomUUID();
    const file: TransferFile = { id, ...insertFile };
    this.transferFiles.set(id, file);
    return file;
  }

  async getTransferFiles(transferId: string): Promise<TransferFile[]> {
    return Array.from(this.transferFiles.values()).filter(f => f.transferId === transferId);
  }

  async getTransferFile(fileId: string): Promise<TransferFile | undefined> {
    return this.transferFiles.get(fileId);
  }
}

export const storage = new MemStorage();
