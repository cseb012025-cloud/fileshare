import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const transfers = pgTable("transfers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: varchar("code", { length: 6 }).notNull().unique(),
  passwordHash: text("password_hash"),
  expiresAt: timestamp("expires_at").notNull(),
  maxDownloads: integer("max_downloads"),
  downloadCount: integer("download_count").notNull().default(0),
  totalSize: integer("total_size").notNull(),
  fileCount: integer("file_count").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const transferFiles = pgTable("transfer_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  transferId: varchar("transfer_id").notNull(),
  originalName: text("original_name").notNull(),
  storedName: text("stored_name").notNull(),
  size: integer("size").notNull(),
  mimeType: text("mime_type").notNull(),
});

export const insertTransferSchema = createInsertSchema(transfers).omit({
  id: true,
  downloadCount: true,
  createdAt: true,
});

export const insertTransferFileSchema = createInsertSchema(transferFiles).omit({
  id: true,
});

export type InsertTransfer = z.infer<typeof insertTransferSchema>;
export type Transfer = typeof transfers.$inferSelect;
export type InsertTransferFile = z.infer<typeof insertTransferFileSchema>;
export type TransferFile = typeof transferFiles.$inferSelect;

// Frontend-specific types
export interface TransferWithFiles extends Transfer {
  files: TransferFile[];
}

export interface UploadFormData {
  expirationValue: number;
  expirationUnit: 'minutes' | 'hours' | 'days';
  password?: string;
  maxDownloads?: number;
}
