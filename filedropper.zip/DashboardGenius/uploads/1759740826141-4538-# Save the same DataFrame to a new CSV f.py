import pandas as pd

# Sample data for 10 rows
data = {
    "Name": [
        "Arun Kumar", "Priya Sharma", "Vikram Singh", "Neha Verma", "Ravi Iyer",
        "Anjali Mehta", "Suresh Reddy", "Kavya Nair", "Rahul Gupta", "Sneha Das"
    ],
    "Phone Number": [
        "9876543210", "9123456780", "9988776655", "9112233445", "9090909090",
        "9123987654", "9345678901", "9456123789", "9234567810", "9345012876"
    ],
    "Email": [
        "arun.kumar@example.com", "priya.sharma@example.com", "vikram.singh@example.com",
        "neha.verma@example.com", "ravi.iyer@example.com", "anjali.mehta@example.com",
        "suresh.reddy@example.com", "kavya.nair@example.com", "rahul.gupta@example.com",
        "sneha.das@example.com"
    ],
    "Time In": [
        "09:00", "09:15", "09:05", "09:20", "09:10",
        "09:30", "09:00", "09:25", "09:15", "09:05"
    ],
    "Time Out": [
        "17:00", "17:15", "17:05", "17:20", "17:10",
        "17:30", "17:00", "17:25", "17:15", "17:05"
    ]
}

# Create DataFrame
df = pd.DataFrame(data)

# Save as CSV file
file_path = "/mnt/data/attendance.csv"
df.to_csv(file_path, index=False)

file_path
