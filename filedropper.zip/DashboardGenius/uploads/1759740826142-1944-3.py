import numpy as np
import pandas as pd
print(np.__version__)
print("Pandas Version:", pd.__version)
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_rows', 500)
series = pd.Series([2, 3, 7, 11, 13, 17, 19, 23])
print(series)
series_df = pd.DataFrame({
'A': range(1, 5),
'B': pd. Timestamp('20190526'),
'C': pd.Series(5,index=list(range(4)), dtype='float64'),
'D':np.array([3]*4,dtype='int64'),
'E':pd.Categorical(["depression","social anxity","bipolar disorder","eating disorder"])
})
print(series_df)
print('\n','ii','\n')

sdf= {'County': ['Ostfold', 'Hordaland', 'Oslo', 'Hedmark', 'Oppland', 'Buskerud'],
'ISO-Code': [1,2,3,4,5,6],
'Area': [4180.69, 4917.94, 454.07, 27397.76, 25192.10, 14910.94],
'Administrative centre': ["Sarpsborg", "Oslo", "City of Oslo", "Hamar",
"Lillehammer", "Drammen"]}
sdf= pd.DataFrame(sdf)
print(sdf)